/* Moli Taste menu — edit names / prices here; both pages update automatically.
   from:true  → shows "起" (starting price, size options).                      */
window.MENU = [
  { id: "pizza", zh: "披萨", en: "Pizza", items: [
    { zh: "奶酪扎塔", en: "Zatar with Cheese", price: 68, img: "pizza-zatar-cheese" },
    { zh: "扎塔", en: "Zatar", price: 58, img: "pizza-zatar" },
    { zh: "凯撒芝士风味炸鸡", en: "Caesar Fried Chicken", price: 58, img: "pizza-caesar" },
    { zh: "四重奶酪", en: "Four Cheese", price: 75, img: "pizza-four-cheese" },
    { zh: "烟熏三文鱼", en: "Smoked Salmon", price: 82, img: "pizza-smoked-salmon" },
    { zh: "鲜烤大虾", en: "Shrimp", price: 78, from: true, img: "pizza-shrimp" },
    { zh: "鲜烤牛肉", en: "Grilled Beef", price: 75, img: "pizza-grilled-beef" },
    { zh: "鲜烤鸡肉", en: "Grilled Chicken", price: 68, from: true, img: "pizza-grilled-chicken" },
    { zh: "混合蔬菜", en: "Vege Mix", price: 68, img: "pizza-vege" },
    { zh: "意式香肠", en: "Pepperoni", price: 75, img: "pizza-pepperoni" },
    { zh: "玛格丽特", en: "Margherita", price: 68, img: "pizza-margherita" },
  ]},
  { id: "specials", zh: "茉莉特色餐", en: "Moli Specials", items: [
    { zh: "茉莉巨无霸盒", en: "Moli Big Box", price: 48, img: "special-moli-box" },
    { zh: "芝士白酱意面", en: "Béchamel Cheese Pasta", price: 58, img: "special-bechamel" },
  ]},
  { id: "burger", zh: "汉堡", en: "Burgers", items: [
    { zh: "鸡肉汉堡", en: "Fried Chicken Burger", price: 38, from: true, img: "burger-chicken" },
    { zh: "牛肉汉堡", en: "Beef Burger", price: 48, from: true, img: "burger-beef" },
  ]},
  { id: "sandwich", zh: "三明治", en: "Sandwiches", items: [
    { zh: "茉莉潜艇·鲜烤鸡肉", en: "Moli Sub · Grilled Chicken", price: 37, img: "sub-grilled-chicken" },
    { zh: "茉莉潜艇·芝士蔬菜", en: "Moli Sub · Cheese & Vegetables", price: 38, img: "sub-cheese" },
    { zh: "茉莉潜艇·鲜烤牛肉", en: "Moli Sub · Grilled Beef", price: 42, img: "sub-grilled-beef" },
    { zh: "茉莉潜艇·凯撒芝士风味炸鸡", en: "Moli Sub · Caesar Fried Chicken", price: 35, img: "sub-caesar" },
    { zh: "那不勒斯·芝士蔬菜", en: "Napolitano · Cheese & Vegetables", price: 48, img: "napo-cheese-veg" },
    { zh: "那不勒斯·鲜烤鸡肉", en: "Napolitano · Grilled Chicken", price: 48, img: "napo-grilled-chicken" },
    { zh: "那不勒斯·鲜烤牛肉", en: "Napolitano · Grilled Beef", price: 51, img: "napo-grilled-beef" },
    { zh: "那不勒斯·意式香肠马苏里拉", en: "Napolitano · Pepperoni Mozzarella", price: 53, img: "napo-pepperoni" },
    { zh: "那不勒斯·凯撒芝士风味炸鸡", en: "Napolitano · Caesar Fried Chicken", price: 45, img: "napo-caesar" },
  ]},
  { id: "coffee", zh: "咖啡", en: "Coffee", items: [
    { zh: "卡布奇诺", en: "Cappuccino", price: 30, img: "coffee-cappuccino" },
    { zh: "拿铁", en: "Latte", price: 28, img: "coffee-latte" },
    { zh: "美式", en: "Americano", price: 15, from: true, img: "coffee-americano" },
    { zh: "浓缩咖啡", en: "Espresso", price: 18, from: true, img: "coffee-espresso" },
  ]},
  { id: "drinks", zh: "饮品", en: "Drinks", items: [
    { zh: "冰草莓果汁", en: "Iced Strawberry Juice", price: 22, img: "drink-strawberry" },
  ]},
  { id: "gelato", zh: "意式冰淇淋", en: "Gelato", items: [
    { zh: "芒果", en: "Mango", price: 16, img: "gelato-mango" },
    { zh: "巧克力", en: "Chocolate", price: 18, img: "gelato-chocolate" },
    { zh: "开心果", en: "Pistachio", price: 22, img: "gelato-pistachio" },
  ]},
  { id: "salad", zh: "沙拉", en: "Salads", items: [
    { zh: "菲达奶酪沙拉", en: "Feta Green Salad", price: 28, from: true, img: "salad-feta" },
    { zh: "三文鱼沙拉", en: "Salmon Salad", price: 32, from: true, img: "salad-salmon" },
    { zh: "凯撒沙拉", en: "Caesar Salad", price: 25, from: true, img: "salad-caesar" },
    { zh: "绿色沙拉", en: "Green Salad", price: 18, from: true, img: "salad-green" },
  ]},
  { id: "snacks", zh: "小吃", en: "Snacks", items: [
    { zh: "鸡柳", en: "Chicken Nuggets", price: 20, img: "snack-nuggets" },
    { zh: "鹰嘴豆泥+面包", en: "Hummus with Bread", price: 28, img: "snack-hummus-bread" },
    { zh: "鹰嘴豆泥", en: "Hummus", price: 20, img: "snack-hummus" },
    { zh: "薯条", en: "Fries", price: 15, from: true, img: "snack-fries" },
  ]},
];
